/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.ifthen2;

/**
 *
 * @author USER
 */
public class IfThen2 {

    public static void main(String[] args) {
        boolean isOn = true;
        
        if (isOn) {
            System.out.println("Menyalakan lampu");
            System.out.println("Menyalakan lampu lain");
        }
    }
}
